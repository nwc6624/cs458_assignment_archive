/**
 * DialogShowNote is a DialogFragment used to display the details of a selected note.
 * It shows the title, description, and optionally displays icons for important, to-do, and idea notes.
 * The user can close the dialog by clicking the OK button.
 *
 * @author Noah Caulfield
 * @date 9/26/2023
 * @version 1.0
 */
package edu.enmu.notetoself;

import android.app.Dialog;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;

public class DialogShowNote extends DialogFragment {

    private Note mNote;

    /**
     * onCreateDialog is called to create and configure the dialog for displaying a note.
     *
     * @param savedInstanceState A Bundle containing the saved instance state.
     * @return A configured AlertDialog displaying the note's details.
     */
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        // Initialize the AlertDialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate the dialog layout
        View dialogView = inflater.inflate(R.layout.dialog_show_note, null);

        // Initialize UI components
        TextView txtTitle = dialogView.findViewById(R.id.txtTitle);
        TextView txtDescription = dialogView.findViewById(R.id.txtDescription);

        txtTitle.setText(mNote.getTitle());
        txtDescription.setText(mNote.getDescription());

        TextView txtImportant = dialogView.findViewById(R.id.textViewImportant);
        TextView txtTodo = dialogView.findViewById(R.id.textViewTodo);
        TextView txtIdea = dialogView.findViewById(R.id.textViewIdea);

        // Hide icons if the note is not important, a to-do, or an idea
        if (!mNote.isImportant()){
            txtImportant.setVisibility(View.GONE);
        }

        if (!mNote.isTodo()){
            txtTodo.setVisibility(View.GONE);
        }

        if (!mNote.isIdea()){
            txtIdea.setVisibility(View.GONE);
        }

        Button btnOK = dialogView.findViewById(R.id.btnOk);

        // Set the view of the dialog and its message
        builder.setView(dialogView).setMessage("Your Note");

        // Handle the OK button click
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        // Create and return the AlertDialog
        return builder.create();
    }

    /**
     * Receive a note from the MainActivity and set it as the note to be displayed.
     *
     * @param noteSelected The selected note to be displayed.
     */
    public void sendNoteSelected(Note noteSelected) {
        mNote = noteSelected;
    }
}
