/**
 * DialogNewNote is a DialogFragment used to display a dialog for creating a new note.
 * Users can input a title, description, and set note attributes such as Idea, To-Do, and Importance.
 * When the user confirms, the new note is created and passed back to the calling activity.
 * @author : Noah Caulfield
 * @date : 9/26/2023
 * @version 1.0
 */
package edu.enmu.notetoself;

import androidx.fragment.app.DialogFragment;
import android.app.Dialog;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class DialogNewNote extends DialogFragment {

    /**
     * onCreateDialog is called to create and configure the new note dialog.
     *
     * @param savedInstanceState A Bundle containing the saved instance state.
     * @return A configured AlertDialog for creating a new note.
     */
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        // Initialize the AlertDialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // Inflate the dialog layout
        View dialogView = inflater.inflate(R.layout.dialog_new_note, null);

        // Initialize UI components
        final EditText editTitle = dialogView.findViewById(R.id.editTitle);
        final EditText editDescription = dialogView.findViewById(R.id.editDescription);
        final CheckBox checkBoxIdea = dialogView.findViewById(R.id.checkBoxIdea);
        final CheckBox checkBoxTodo = dialogView.findViewById(R.id.checkBoxTodo);
        final CheckBox checkBoxImportant = dialogView.findViewById(R.id.checkBoxImportant);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);
        Button btnOK = dialogView.findViewById(R.id.btnOK);

        // Set the view of the dialog and its message
        builder.setView(dialogView).setMessage("Add a new note");

        // Handle the cancel button click
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        // Handle the OK button click
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Create a new note
                Note newNote = new Note();

                // Set note properties based on user input
                newNote.setTitle(editTitle.getText().toString());
                newNote.setDescription(editDescription.getText().toString());
                newNote.setIdea(checkBoxIdea.isChecked());
                newNote.setTodo(checkBoxTodo.isChecked());
                newNote.setImportant(checkBoxImportant.isChecked());

                // Get a reference to the calling MainActivity
                MainActivity callingActivity = (MainActivity) getActivity();

                // Pass the newNote back to MainActivity
                callingActivity.createNewNote(newNote);

                // Close the dialog
                dismiss();
            }
        });

        // Create and return the AlertDialog
        return builder.create();
    }
}