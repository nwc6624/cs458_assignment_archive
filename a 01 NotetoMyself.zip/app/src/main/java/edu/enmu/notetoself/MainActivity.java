/**
 * MainActivity is the main activity of the Note to Self app. It provides a user interface for
 * creating new notes and displaying existing notes.
 *
 * @author Noah Caulfield
 * @date 9/15/2023
 * @version 1.0
 */
package edu.enmu.notetoself;

import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // Temporary code
    Note mTempNote = new Note();

    /**
     * onCreate is called when the activity is first created. It sets up the user interface
     * and handles button click events.
     *
     * @param savedInstanceState A Bundle containing the saved instance state.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogNewNote dialog = new DialogNewNote();
                dialog.show(getSupportFragmentManager(), "");
            }
        });

        // Temporary code
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new DialogShowNote called dialog
                DialogShowNote dialog = new DialogShowNote();

                // Send the note via the sendNoteSelected method
                dialog.sendNoteSelected(mTempNote);

                // Create the dialog
                dialog.show(getSupportFragmentManager(), "123");
            }
        });
    }

    /**
     * onCreateOptionsMenu inflates the menu for the activity.
     *
     * @param menu The menu to inflate.
     * @return True if the menu was inflated successfully, false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     * onOptionsItemSelected handles menu item clicks.
     *
     * @param item The selected menu item.
     * @return True if the item's action was handled, false otherwise.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * createNewNote is a method for temporarily storing a new note.
     *
     * @param n The new note to be stored.
     */
    public void createNewNote(Note n) {
        // Temporary code
        mTempNote = n;
    }
}
