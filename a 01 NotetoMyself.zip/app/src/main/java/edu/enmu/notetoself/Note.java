/**
 * The Note class represents a note with a title, description, and attributes indicating whether it
 * is an idea, a to-do item, or important.
 *
 * @author Noah Caulfield
 * @date 9/26/2023
 * @version 1.0
 */
package edu.enmu.notetoself;

public class Note {
    private String mTitle;
    private String mDescription;
    private boolean mIdea;
    private boolean mTodo;
    private boolean mImportant;

    /**
     * Gets the title of the note.
     *
     * @return The title of the note.
     */
    public String getTitle() {
        return mTitle;
    }

    /**
     * Sets the title of the note.
     *
     * @param mTitle The title to set for the note.
     */
    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    /**
     * Gets the description of the note.
     *
     * @return The description of the note.
     */
    public String getDescription() {
        return mDescription;
    }

    /**
     * Sets the description of the note.
     *
     * @param mDescription The description to set for the note.
     */
    public void setDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    /**
     * Checks if the note is an idea.
     *
     * @return True if the note is an idea, false otherwise.
     */
    public boolean isIdea() {
        return mIdea;
    }

    /**
     * Sets whether the note is an idea.
     *
     * @param mIdea True if the note is an idea, false otherwise.
     */
    public void setIdea(boolean mIdea) {
        this.mIdea = mIdea;
    }

    /**
     * Checks if the note is a to-do item.
     *
     * @return True if the note is a to-do item, false otherwise.
     */
    public boolean isTodo() {
        return mTodo;
    }

    /**
     * Sets whether the note is a to-do item.
     *
     * @param mTodo True if the note is a to-do item, false otherwise.
     */
    public void setTodo(boolean mTodo) {
        this.mTodo = mTodo;
    }

    /**
     * Checks if the note is important.
     *
     * @return True if the note is important, false otherwise.
     */
    public boolean isImportant() {
        return mImportant;
    }

    /**
     * Sets whether the note is important.
     *
     * @param mImportant True if the note is important, false otherwise.
     */
    public void setImportant(boolean mImportant) {
        this.mImportant = mImportant;
    }
}
