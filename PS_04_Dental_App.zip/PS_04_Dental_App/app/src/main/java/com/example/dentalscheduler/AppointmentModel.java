/**
 * The AppointmentModel class leverages the SQLiteOpenHelper through the AppointmentDatabaseHelper
 * to facilitate database interactions. It provides methods to save new appointments and retrieve existing
 * appointment records from the database.
 *
 * Methods include saving an appointment to the database, checking if a specific date and time
 * are available for booking, and retrieving all appointments in descending order by date and time.
 *
 * @author Noah Caulfield
 * @date 11/07/2023
 * @version 1.0
 * @name: AppointmentModel.java
 *
 * intended for CS 458 via ENMU
 */
package com.example.dentalscheduler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppointmentModel {
    private SQLiteOpenHelper dbHelper;

    /**
     * Constructs an AppointmentModel with the specified context.
     *
     * @param context The context through which the database can be accessed.
     */
    public AppointmentModel(Context context) {
        dbHelper = new AppointmentDatabaseHelper(context);
    }

    /**
     * Attempts to save an appointment to the database. It checks if the appointment time slot is available
     * and inserts the appointment details if it is.
     *
     * @param name The name of the individual for the appointment.
     * @param dob The date of birth of the individual.
     * @param address The address of the individual.
     * @param identificationNumber The identification number of the individual.
     * @param appointmentDate The date of the appointment.
     * @param appointmentTime The time of the appointment.
     * @param description A description of the appointment.
     * @param referralSource The source of the referral for the appointment.
     * @return true if the appointment is successfully saved; false otherwise.
     */
    public boolean saveAppointment(String name, String dob, String address, String identificationNumber,
                                   String appointmentDate, String appointmentTime, String description,
                                   String referralSource) {
        SQLiteDatabase database = null;
        try {
            database = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", name);
            values.put("dob", dob);
            values.put("address", address);
            values.put("identification_number", identificationNumber);
            values.put("appointment_date", appointmentDate);
            values.put("appointment_time", appointmentTime);
            values.put("description", description);
            values.put("referral_source", referralSource);
            values.put("is_time_slot_taken", 0);

            if (isDateTimeAvailable(appointmentDate, appointmentTime, database)) {
                long newRowId = database.insert("appointments", null, values);
                return newRowId != -1;
            } else {
                return false;
            }
        } finally {
            if (database != null) {
                database.close();
            }
        }
    }

    /**
     * Checks if a specific date and time are available for an appointment.
     *
     * @param appointmentDate The date of the appointment to check.
     * @param appointmentTime The time of the appointment to check.
     * @param database The database to query against.
     * @return true if the date and time are available; false otherwise.
     */
    private boolean isDateTimeAvailable(String appointmentDate, String appointmentTime, SQLiteDatabase database) {
        String selection = "appointment_date = ? AND appointment_time = ?";
        String[] selectionArgs = {appointmentDate, appointmentTime};

        Cursor cursor = database.query(
                "appointments",
                new String[]{"id"},
                selection,
                selectionArgs,
                null,
                null,
                null
        );
        boolean isAvailable = !cursor.moveToFirst();
        cursor.close();
        return isAvailable;
    }

    /**
     * Retrieves all appointments from the database ordered by date and time in descending order.
     *
     * @return a Cursor object containing all appointments.
     */
    public Cursor getAllAppointments() {
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        return database.query("appointments", null, null, null, null, null, "appointment_date DESC, appointment_time DESC");
    }
}
