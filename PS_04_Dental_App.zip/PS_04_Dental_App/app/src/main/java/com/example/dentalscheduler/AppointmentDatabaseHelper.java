package com.example.dentalscheduler;

/**
 * The class is responsible for managing the app's database operations. It oversees establishing,
 * accessing, and administering the database through extending SQLiteOpenHelper.
 * This class specifically handles the creation and versioning of the database schema.
 *
 * @author Noah Caulfield
 * @date 11/07/2023
 * @version 1.0
 *
 * AppointmentDatabaseHelper.java
 *
 * Intended for CS 458 at ENMU
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppointmentDatabaseHelper extends SQLiteOpenHelper {

    /** Database version. */
    public static final int DATABASE_VERSION = 1;
    /** Database name. */
    public static final String DATABASE_NAME = "Appointment.db";

    /** SQL statement to create a new appointments table. */
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE appointments (" +
                    "id INTEGER PRIMARY KEY," +
                    "name TEXT," +
                    "dob TEXT," +
                    "address TEXT," +
                    "identification_number TEXT," +
                    "appointment_date TEXT," +
                    "appointment_time TEXT," +
                    "description TEXT," +
                    "referral_source TEXT," +
                    "is_time_slot_taken INTEGER" + // Use 0 for false and 1 for true
                    ");";

    /** SQL statement to delete the appointments table. */
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS appointments";

    /**
     * Constructor that takes the context and calls the superclass constructor with the
     * database name and version.
     *
     * @param context the context in which to operate the database
     */
    public AppointmentDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables should happen.
     *
     * @param db the database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    /**
     * Called when the database needs to be upgraded. This method will only be called if
     * a database already exists on disk with the same DATABASE_NAME, but the DATABASE_VERSION
     * is different than the version of the database that exists on disk.
     *
     * @param db the database.
     * @param oldVersion the old database version.
     * @param newVersion the new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}
