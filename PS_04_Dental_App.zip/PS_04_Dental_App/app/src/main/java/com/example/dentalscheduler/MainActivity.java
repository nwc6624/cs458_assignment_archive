/**
 * Defines the MainActivity class for the Dentistry Android app, managing the UI for scheduling
 * dental appointments. It initializes input fields, a date picker, and selection spinners,
 * and binds them in the onCreate method. The submitForm method validates and processes user input,
 * saving it if valid, while showAllAppointments displays existing appointments. This class is
 * responsible for managing user interactions and facilitating the appointment scheduling process.
 *
 * @author Noah Caulfield
 * @date 11/07/2023
 * @version 1.0
 *
 * Intended for CS 458 at ENMU
 */
package com.example.dentalscheduler;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    // UI references
    private EditText patientNameEditText, patientDoBEditText, patientAddressEditText, patientIdEditText, patientDescriptionEditText;
    private Spinner timeSlotSpinner, referralSourceSpinner;
    private CalendarView appointmentDateCalendarView;
    private Button submitButton, showAllButton;
    private AppointmentModel appointmentModel; // The model for database operations

    /**
     * Called when the activity is starting. This method is where the activity's UI is created
     * and initialized. It binds the UI to the activity logic, sets up the data model, and
     * registers event listeners for user interaction with the UI components.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously
     *                           being shut down, this Bundle contains the data most
     *                           recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<String> blockedDates = Arrays.asList(
                "11/10/2023", "11/23/2023",      //Federal holidays
                "12/25/2023", "01/01/2024", "01/15/2024", "02/19/2024", "05/27/2024",
                "06/19/2024", "07/04/2024", "09/02/2024", "10/14/2024", "11/11/2024",
                "11/28/2024", "12/25/2024"
        );
        appointmentDateCalendarView = findViewById(R.id.appointmentDate);
        Calendar maxDate = Calendar.getInstance();
// Set the date to December 1st, 2024, then subtract one millisecond to get the last millisecond of November 2024
        maxDate.set(2024, Calendar.NOVEMBER, 9);
        maxDate.add(Calendar.MILLISECOND, -1);
        appointmentDateCalendarView.setMaxDate(maxDate.getTimeInMillis());

// Set the minimum date to November 1st, 2023
        Calendar minDate = Calendar.getInstance();
        minDate.set(2023, Calendar.NOVEMBER, 9);
        appointmentDateCalendarView.setMinDate(minDate.getTimeInMillis());

        appointmentDateCalendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String selectedDate = String.format(Locale.US, "%02d/%02d/%04d", month + 1, dayOfMonth, year);
            if (blockedDates.contains(selectedDate)) {
                Toast.makeText(this, "Selected date is a holiday and not available for booking.", Toast.LENGTH_LONG).show();
                // Logic to handle blocked date selection
            }
        });

        // Initialize references to views
        patientNameEditText = findViewById(R.id.patientName);
        patientDoBEditText = findViewById(R.id.patientDoB);
        patientAddressEditText = findViewById(R.id.patientAddress);
        patientIdEditText = findViewById(R.id.patientId);
        patientDescriptionEditText = findViewById(R.id.patientDescription);
        timeSlotSpinner = findViewById(R.id.timeSlotSpinner);
        referralSourceSpinner = findViewById(R.id.referralSourceSpinner);
        appointmentDateCalendarView = findViewById(R.id.appointmentDate);
        submitButton = findViewById(R.id.submitButton);
        showAllButton = findViewById(R.id.showAllButton);

        // Initialize the model
        appointmentModel = new AppointmentModel(this);

        // Initialize the CalendarView and set the maximum date
        appointmentDateCalendarView = findViewById(R.id.appointmentDate);
        // Calendar maxDate = Calendar.getInstance();
        // Set the date to December 1st, 2024, then subtract one millisecond to get the last millisecond of November 2024
        maxDate.set(2024, Calendar.DECEMBER, 1);
        maxDate.add(Calendar.MILLISECOND, -1);
        appointmentDateCalendarView.setMaxDate(maxDate.getTimeInMillis());

        // Populate time slot spinner
        String[] timeSlots = {"8-9 AM", "9-10 AM", "10-11 AM", "11-12 PM", "1-2 PM", "2-3 PM", "3-4 PM", "4-5 PM"};
        ArrayAdapter<String> timeSlotAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, timeSlots);
        timeSlotSpinner.setAdapter(timeSlotAdapter);

        // Populate referral source spinner with a custom adapter to handle the prompt
        String[] referralSources = {"How did you hear about us", "Radio", "Newspaper", "Television", "Internet", "Referral"};
        ArrayAdapter<String> referralSourceAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, referralSources) {
            /**
             * Determines whether an item at a specific position is enabled. This method is overridden to
             * disable the first item in the spinner, which is used as a non-selectable prompt. By returning
             * false for the first position, the item is made non-clickable and non-selectable, ensuring that
             * it only serves as a prompt and not an actual selectable option.
             *
             * @param position The position of the item within the adapter's data set.
             * @return true if the item at the specified position is selectable and clickable;
             *         false otherwise. Here, the first item is not enabled.
             */
            @Override
            public boolean isEnabled(int position) {
                // Disable the first item which is used as the prompt
                return position != 0;
            }
            /**
             * Customizes the appearance of the dropdown view in the spinner. This method is overridden
             * to modify the alpha property of the prompt item in the dropdown list, visually indicating
             * that it is not selectable. The prompt item is dimmed by setting its alpha value to 0.5,
             * while all other items are kept at full opacity (alpha value 1.0).
             *
             * @param position The position of the item within the adapter's data set of the item whose
             *                 view we want.
             * @param convertView The old view to reuse, if possible. Note: You should check that this
             *                    view is non-null and of an appropriate type before using. If it is not
             *                    possible to convert this view to display the correct data, this method
             *                    can create a new view.
             * @param parent The parent that this view will eventually be attached to.
             * @return A View corresponding to the data at the specified position.
             */
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                // Dim the prompt in the dropdown to show it's not selectable
                view.setAlpha(position == 0 ? 0.5f : 1.0f);
                return view;
            }
        };

        /**
         * Adds a TextWatcher to the patient's date of birth EditText field. The TextWatcher is configured
         * to format the date input dynamically by inserting slashes as the user types, ensuring the
         * date is entered in a correct format. This listener acts after the text has changed in the EditText.
         */
        patientDoBEditText.addTextChangedListener(new TextWatcher() {
            private String lastInput = ""; // Holds the previous input to compare with the current input.

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Method stub for before text changed event; not used in this implementation.
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Method stub for on text changed event; not used in this implementation.
            }

            /**
             * This method is called to notify you that, somewhere within `s`, the text has been
             * changed. It is legitimate to make further changes to `s` from this callback but
             * be careful not to get yourself into an infinite loop because any changes you make
             * will cause this method to be called again recursively. You are not told where the
             * change took place because other afterTextChanged() methods may already have made
             * other changes and invalidated the offsets.
             *
             * @param s Editable containing the modified text.
             */
            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString();
                if (!lastInput.equals(input)) {
                    StringBuilder sb = new StringBuilder(input);

                    // Process the input if characters are being added.
                    if (input.length() > lastInput.length()) {
                        // Insert slashes at the right positions (MM/DD/YYYY).
                        if (input.length() == 3 || input.length() == 6) {
                            sb.insert(input.length() - 1, "/");
                        }
                    }

                    // Update the last input string.
                    lastInput = sb.toString();

                    // Remove the listener to prevent infinite loop before setting the EditText content.
                    patientDoBEditText.removeTextChangedListener(this);
                    // Set the new text to the EditText and place the cursor at the end.
                    patientDoBEditText.setText(lastInput);
                    patientDoBEditText.setSelection(lastInput.length());
                    // Reattach the listener after the update.
                    patientDoBEditText.addTextChangedListener(this);
                }
            }
        });

        referralSourceSpinner.setAdapter(referralSourceAdapter);


        /**
         * Assigns an OnItemSelectedListener to the referral source spinner. This listener is activated
         * whenever an item in the spinner is selected. The purpose is to reset the spinner's prompt to
         * the default non-selectable state if the user selects the prompt item itself.
         */
        referralSourceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * Callback method to be invoked when an item in this view has been selected. This callback
             * is invoked only when the newly selected position is different from the previously selected
             * position or if there was no selected item.
             *
             * Implementers can call getItemAtPosition(position) if they need to access the data associated
             * with the selected item.
             *
             * @param parent The AdapterView where the selection happened.
             * @param view The view within the AdapterView that was clicked.
             * @param position The position of the view in the adapter.
             * @param id The row id of the item that is selected.
             */
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    // Updates the TextView of the selected view to show the prompt text, indicating
                    // it is not a selectable item. This is a UI cue to the user that they should
                    // select one of the other, actionable items in the spinner.

                    ((TextView) view).setText(referralSources[0]);
                }
            }

            /**
             * Overrides the onNothingSelected method for the spinner. This method is called when
             * the selection disappears from this view. The typical scenario is when the user
             * navigates with the keyboard to deselect the current selection. Since no action is
             * defined, this method is empty.
             *
             * @param parent The AdapterView where the selection happened.
             */
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        /**
         * Sets up an OnClickListener for the 'submit' button. When the button is clicked,
         * it triggers the submission of the form.
         */
        submitButton.setOnClickListener(view -> submitForm());

        /**
         * Sets up an OnClickListener for the 'show all' button. When the button is clicked,
         * it triggers the display of all the appointments.
         */
        showAllButton.setOnClickListener(view -> showAllAppointments());
    }

    /**
     * Gathers all user inputs from the form, validates them, and if valid, proceeds to save the
     * appointment information into the database using the AppointmentModel. It performs checks to
     * ensure all fields are filled in and notifies the user if any validation fails. On successful
     * saving of the appointment, a confirmation message is displayed. If there's an issue with saving
     * the appointment (such as a scheduling conflict), an error message is shown instead.
     */
    private void submitForm() {
        // Retrieve user input from form fields
        String name = patientNameEditText.getText().toString();
        String dob = patientDoBEditText.getText().toString();
        String address = patientAddressEditText.getText().toString();
        String identificationNumber = patientIdEditText.getText().toString();
        String description = patientDescriptionEditText.getText().toString();
        String timeSlot = timeSlotSpinner.getSelectedItem().toString();
        String referralSource = referralSourceSpinner.getSelectedItem().toString();

        // Obtain the appointment date selected in the CalendarView and format it
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(appointmentDateCalendarView.getDate());
        String appointmentDate = String.format("%d-%02d-%02d", calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));

        // Check for empty fields and alert the user if any are found
        if (name.isEmpty() || dob.isEmpty() || address.isEmpty() || identificationNumber.isEmpty() || description.isEmpty()) {
            showAlert("All fields are required.");
        } else {
            // Attempt to save the appointment in the database
            boolean isSaved = appointmentModel.saveAppointment(name, dob, address, identificationNumber,
                    appointmentDate, timeSlot, description, referralSource);
            // Notify the user of the outcome of the save operation
            if (isSaved) {
                Toast.makeText(getApplicationContext(), "Appointment successfully submitted for " +
                        appointmentDate + " at " + timeSlot, Toast.LENGTH_LONG).show();
            } else {
                showAlert("Failed to save the appointment due to a conflict. Please try again.");
            }
        }
    }



    /**
     * Displays an alert dialog with a specified message to the user. This method is typically used
     * to notify the user of validation errors, confirmations, or other important information that
     * requires immediate attention. The dialog presented is modal and will require user interaction
     * before they can proceed with other actions.
     *
     * @param message The message to be displayed in the alert dialog. This should be a concise,
     *                user-friendly explanation or notification.
     */
    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(message) // Sets the message to be displayed.
                .setTitle("Attention") // Sets the title of the AlertDialog.
                .setPositiveButton("OK", null); // Sets the positive button with a text of "OK" and no OnClickListener.
        AlertDialog dialog = builder.create(); // Creates the AlertDialog object.
        dialog.show(); // Displays the dialog to the user.
    }


    /**
     * Fetches and displays all scheduled appointments from the database.
     * It builds a formatted string with appointment details and shows it in an alert dialog.
     * The method retrieves the data using a cursor from the AppointmentModel and iterates through
     * the results, extracting the necessary information. If any of the required columns are missing,
     * it notifies the user of the error; otherwise, it displays the appointment data.
     */
    private void showAllAppointments() {
        Cursor cursor = appointmentModel.getAllAppointments();
        if (cursor != null && cursor.moveToFirst()) {
            StringBuilder stringBuilder = new StringBuilder();

            // Retrieve column indexes from the cursor based on the column names.
            int nameColumnIndex = cursor.getColumnIndex("name");
            int dobColumnIndex = cursor.getColumnIndex("dob");
            int dateColumnIndex = cursor.getColumnIndex("appointment_date");
            int timeColumnIndex = cursor.getColumnIndex("appointment_time");
            // Additional column indexes would be retrieved here.

            // Verify that all required columns are present.
            if (nameColumnIndex == -1 || dobColumnIndex == -1 || dateColumnIndex == -1 || timeColumnIndex == -1) {
                Toast.makeText(this, "Error: One of the columns does not exist", Toast.LENGTH_SHORT).show();
                return;
            }

            // Loop through the cursor results and append them to the StringBuilder.
            do {
                String name = cursor.getString(nameColumnIndex);
                String dob = cursor.getString(dobColumnIndex);
                String appointmentDate = cursor.getString(dateColumnIndex);
                String appointmentTime = cursor.getString(timeColumnIndex);
                // Other fields could be appended here as well.

                stringBuilder.append("Name: ").append(name)
                        .append(", DOB: ").append(dob)
                        .append(", Date: ").append(appointmentDate)
                        .append(", Time: ").append(appointmentTime)
                        .append("\n\n");
            } while (cursor.moveToNext());

            // Create and show an AlertDialog with the appointment information.
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("All Appointments")
                    .setMessage(stringBuilder.toString())
                    .setPositiveButton("OK", null)
                    .create()
                    .show();

            // Close the cursor once done to free resources.
            cursor.close();
        } else {
            // Notify the user if no appointments were found.
            Toast.makeText(this, "No appointments found", Toast.LENGTH_SHORT).show();
        }
    }
}


